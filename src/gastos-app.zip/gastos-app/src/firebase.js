// src/firebase.js
// ─────────────────────────────────────────────────────────────
// PASO 1: Reemplazá estos valores con los de tu proyecto Firebase.
// Los encontrás en: Firebase Console → tu proyecto → ⚙️ → Configuración del proyecto
// ─────────────────────────────────────────────────────────────
import { initializeApp } from "firebase/app";
import { getAuth }        from "firebase/auth";
import { getFirestore }   from "firebase/firestore";

const firebaseConfig = {
  apiKey:            "REEMPLAZAR",
  authDomain:        "REEMPLAZAR",
  projectId:         "REEMPLAZAR",
  storageBucket:     "REEMPLAZAR",
  messagingSenderId: "REEMPLAZAR",
  appId:             "REEMPLAZAR",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db   = getFirestore(app);
